(** We were inspired for the code of two helper methods. One being an
    OCaml implementation for the permutations of a list and the other to
    handle file names of a directory.*)

let hours_worked_ms1 = 40

let hours_worked_ms2 = 125

let hours_worked_ms3 = 300
